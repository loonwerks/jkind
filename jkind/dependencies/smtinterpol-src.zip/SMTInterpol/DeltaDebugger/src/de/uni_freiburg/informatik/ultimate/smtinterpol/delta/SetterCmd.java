/*
 * Copyright (C) 2012-2013 University of Freiburg
 *
 * This file is part of SMTInterpol.
 *
 * SMTInterpol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SMTInterpol is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SMTInterpol.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.uni_freiburg.informatik.ultimate.smtinterpol.delta;

import java.io.PrintWriter;


public class SetterCmd extends Cmd {
	
	private final String mCmd;
	private final boolean mCanBeRemoved;
	private final String mKey;
	private final Object mVal;
	
	public SetterCmd(String cmd, String key, Object val) {
		mCmd = cmd;
		// Remove most infos but keep options...
		/* This strategy might be bad if proof production is enabled but the
		 * error does not depend on a proof.  Maybe we should implement a
		 * feature collection...
		 */
		boolean isInfo = cmd == "set-info";
		mCanBeRemoved = !((isInfo && key.equals(":error-behavior")) // NOPMD
				|| (!isInfo && (key.startsWith(":produce-")
						|| key.endsWith("-check-mode"))));
		mKey = key;
		mVal = val;
		
	}

	@Override
	public boolean canBeRemoved() {
		return mCanBeRemoved;
	}

	@Override
	public void dump(PrintWriter writer) {
		writer.print('(');
		writer.print(mCmd);
		writer.print(' ');
		writer.print(mKey);
		writer.print(' ');
		writer.print(mVal);
		writer.println(')');
	}
	
	public String toString() {
		return mCmd.toUpperCase();
	}

	@Override
	public String provideFeature() {
		return mCmd == "set-option" ? mKey : null;
	}

}
