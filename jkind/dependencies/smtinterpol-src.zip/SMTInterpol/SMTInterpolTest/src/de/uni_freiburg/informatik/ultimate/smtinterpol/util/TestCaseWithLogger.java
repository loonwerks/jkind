/*
 * Copyright (C) 2009-2012 University of Freiburg
 *
 * This file is part of SMTInterpol.
 *
 * SMTInterpol is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SMTInterpol is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with SMTInterpol.  If not, see <http://www.gnu.org/licenses/>.
 */
package de.uni_freiburg.informatik.ultimate.smtinterpol.util;

import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class TestCaseWithLogger {
	
	static { 
		Logger logger = Logger.getRootLogger();
		if (!logger.getAllAppenders().hasMoreElements()) {
			SimpleLayout layout = new SimpleLayout();
			logger.addAppender(new ConsoleAppender(layout));
		}
	}
	
	protected TestCaseWithLogger() {
		this(Level.DEBUG);
	}
	
	protected TestCaseWithLogger(Level level) {
		Logger.getRootLogger().setLevel(level);
	}
}
